/* tslint:disable */
require("./MenuIcon.module.css");
const styles = {
  menuItem: 'menuItem_9a4ee5b5',
  outerContainer: 'outerContainer_9a4ee5b5'
};

export default styles;
/* tslint:enable */