import * as React from "react";
import styles from "./InsuranceNapa.module.scss";
import { IInsuranceNapaProps } from "./IInsuranceNapaProps";
import { escape } from "@microsoft/sp-lodash-subset";
import MenuIcon from "./MenuIcon";
import HeaderInfo from "./HeaderInfo";
import {
  TextField,
  Checkbox,
  ICheckboxProps,
  Dropdown,
  DropdownMenuItemType,
  IDropdownStyles,
  IDropdownOption,
  DatePicker,
  IStackStyles,
  IStackProps,
  Stack,
  autobind,
  Toggle,
  Separator,
  DefaultButton,
  PrimaryButton,
  ITextFieldProps,
  getTheme,
  FontWeights,
  ITheme,
  Label,
} from "office-ui-fabric-react/lib";
import {
  PeoplePicker,
  PrincipalType,
} from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { InsuranceNapaState } from "./InsuranceNapaState";
import { SPHttpClient } from "@microsoft/sp-http";
import { IProposal } from "./IProposal";
import FilteredDropdown from "./FilteredDropdown";

const stackTokens = { childrenGap: 50 };
const stackStyles: Partial<IStackStyles> = { root: { width: 784 } };
const columnProps: Partial<IStackProps> = {
  tokens: { childrenGap: 10 },
  styles: { root: { width: 450 } },
};
const dropdownStyles: Partial<IDropdownStyles> = { dropdown: { width: 300 } };
const proposalObj = {
  countriesListname: "Countries",
  productsListname: "Products",
  jurisdictionListname: "Jurisdiction",
  targetClientSectorListname: "Target Client Sector",
  currenciesListname: "Currencies",
  natureOfTradeListname: "Nature Of Trade",
  bookingLegalEntitiesListname: "Booking Legal Entities",
  napaProposalsListname: "NAPA Proposals",
  userObjects: [],
  userObjectsCount: 0,
};
const proposalRegions: IDropdownOption[] = [
  { key: "ARO", text: "ARO" },
  { key: "SA", text: "SA" },
  { key: "UK", text: "UK" },
  { key: "USA", text: "USA" },
];

export default class InsuranceNapa extends React.Component<
  IInsuranceNapaProps,
  InsuranceNapaState
> {
  constructor(props: IInsuranceNapaProps, state: InsuranceNapaState) {
    super(props);
    this.state = {
      allCountries: [],
      shortCountries: [],
      bookingCurrencies: [],
      tradeActivities: [],
      legalEntities: [],
      users: [],
      clientSectors: [],
      companies: [],
      businessAreas: [],
      productAreas: [],
      subProducts: [],
      proposalObject: {},
    };
  }
  public async componentDidMount(): Promise<void> {
    const handler = this;
    const allCountriesArr: IDropdownOption[] = [];
    const someCountries: IDropdownOption[] = [];
    const clientSectorsArr: IDropdownOption[] = [];
    const bookingCurrenciesArr: IDropdownOption[] = [];
    const tradeActivityArr: IDropdownOption[] = [];
    const legalEntityArr: IDropdownOption[] = [];

    //load countries
    this._getListitems(proposalObj.countriesListname).then((allCountries) => {
      allCountries.forEach((country) => {
        if (country.IsProposalCountry)
          someCountries.push({ key: country.Title, text: country.Title });
        allCountriesArr.push({ key: country.Title, text: country.Title });
      });
      this.setState({ allCountries: allCountriesArr });
      this.setState({ shortCountries: someCountries });
    });
    //load Target Client Sector
    this._loadDropdownFromSP(
      proposalObj.targetClientSectorListname,
      clientSectorsArr
    );
    this.setState({ clientSectors: clientSectorsArr });

    //load Booking/Applicable Currencies
    this._loadDropdownFromSP(
      proposalObj.currenciesListname,
      bookingCurrenciesArr
    );
    this.setState({ bookingCurrencies: bookingCurrenciesArr });

    //load Nature of Trade Activity
    this._loadDropdownFromSP(
      proposalObj.natureOfTradeListname,
      tradeActivityArr
    );
    this.setState({ tradeActivities: tradeActivityArr });

    //load Booking Legal Entity
    this._loadDropdownFromSP(
      proposalObj.bookingLegalEntitiesListname,
      legalEntityArr
    );
    this.setState({ legalEntities: legalEntityArr });

    //load Company
    this._loadCompany();

    // get Proposal
    this._getListitem(proposalObj.napaProposalsListname, 133).then((item) => {
      const _item: IProposal = item as IProposal;
      this.setState({ proposalObject: _item });
      console.log(this);
      console.log("_item:", _item);
      console.log("item", item);
    });
  }
  protected _loadDropdownFromSP(
    listName: string,
    dropdownArray: IDropdownOption[]
  ) {
    this._getListitems(listName).then((responseItems) => {
      responseItems.forEach((responseItem) => {
        if (responseItem.Alphabetic_x0020_Code) {
          dropdownArray.push({
            key: responseItem.ID,
            text: responseItem.Alphabetic_x0020_Code,
          });
        } else
          dropdownArray.push({
            key: responseItem.ID,
            text: responseItem.Title,
          });
        // this.setState({ clientSectors: clientSectorsArr });
      });
    });
  }
  private _getListitems(listName: string): Promise<any[]> {
    const url: string =
      this.props.context.pageContext.site.absoluteUrl +
      "/_api/web/lists/getbytitle('" +
      listName +
      "')/items";
    return this.props.context.spHttpClient
      .get(url, SPHttpClient.configurations.v1)
      .then((response) => {
        return response.json();
      })
      .then((jsonResponse) => {
        return jsonResponse.value;
      }) as Promise<any[]>;
  }
  private _getListitem(listName: string, itemId: number): Promise<any> {
    const url: string =
      this.props.context.pageContext.site.absoluteUrl +
      "/_api/web/lists/getbytitle('" +
      listName +
      "')/items(" +
      itemId +
      ")";
    return this.props.context.spHttpClient
      .get(url, SPHttpClient.configurations.v1)
      .then((response) => {
        return response.json();
      })
      .then((jsonResponse) => {
        return jsonResponse;
      }) as Promise<any>;
  }
  private _getListitemsFilter(
    listName: string,
    filter: string
  ): Promise<any[]> {
    const url: string =
      this.props.context.pageContext.site.absoluteUrl +
      "/_api/web/lists/getbytitle('" +
      listName +
      "')/items?$filter=" +
      filter;
    return this.props.context.spHttpClient
      .get(url, SPHttpClient.configurations.v1)
      .then((response) => {
        return response.json();
      })
      .then((jsonResponse) => {
        return jsonResponse.value;
      }) as Promise<any[]>;
  }
  private _loadCompany() {
    this._getListitems(proposalObj.productsListname).then((products) => {
      const productsArray: IDropdownOption[] = [];
      products.forEach((product) => {
        if (
          !productsArray.some((item) => {
            return item.text === product.Title;
          })
        )
          productsArray.push({ key: product.Title, text: product.Title });
      });
      this.setState({ companies: productsArray });
    });
  }
  @autobind
  private _loadFilteredDropdown(fieldName: string, columnName: string) {
    const companyName = document.getElementById("ddlCompany").firstChild
      .textContent!;
    this._getListitemsFilter(
      proposalObj.productsListname,
      "Title eq '" + companyName + "'"
    ).then((filteredItems) => {
      const arrayToLoad: IDropdownOption[] = [
        { key: "0", text: "", selected: true },
      ];
      filteredItems.forEach((filteredItem) => {
        //debugger;
        if (filteredItem[columnName]) {
          if (
            !arrayToLoad.some((item) => {
              return item.text === filteredItem[columnName];
            })
          )
            arrayToLoad.push({
              key: filteredItem[columnName],
              text: filteredItem[columnName],
            });
        }
      });

      if (fieldName === "ddlProductArea")
        this.setState({ productAreas: arrayToLoad });
      if (fieldName === "ddlBusinessArea")
        this.setState({ businessAreas: arrayToLoad });
      if (fieldName === "ddlSubProducts")
        this.setState({ subProducts: arrayToLoad });
    });
  }
  @autobind
  private _getPeoplePickerItems(items: any[]) {
    let getSelectedUsers = [];
    for (let item in items) {
      getSelectedUsers.push(items[item].id);
    }
    //this.setState({ users: getSelectedUsers });
  }
  @autobind
  private _onChange(): void {
    console.log(this);
  }
  @autobind
  private _saveApplicationProposal() {
    console.log(this);
  }
  @autobind
  private _cancelProposal() {
    console.log(this);
  }
  public render(): React.ReactElement<IInsuranceNapaProps> {
    return (
      <div className={styles.insuranceNapa}>
        {/* <div className={styles.menuItem}>Enquiery</div> */}
        <MenuIcon iconName="Headset" stageName="Enquiery" activated={false} />

        <Stack>
          <HeaderInfo
            title="Application Information"
            description="Provide the following administrative information"
          />
          <Stack horizontal tokens={stackTokens} styles={stackStyles}>
            <Stack {...columnProps}>
              <TextField
                label="Proposal Name:"
                required
                value={this.state.proposalObject.Title}
                description="The proposal name should contain the key distinguishing attributes associated with the proposal."
              />
              <PeoplePicker
                context={this.props.context}
                titleText="Application completed by"
                personSelectionLimit={3}
                showtooltip={true}
                disabled={false}
                // defaultSelectedUsers={[
                //   this.state.proposalObject.AppCreatedById.toString(),
                // ]}
                // selectedItems={this._getPeoplePickerItems}
                showHiddenInUI={false}
                ensureUser={true}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000}
              />
              <Label className={styles.inputDesc}>
                The Product Originator is a business representative or business
                manager, or his/her delegate. The Originator will also be the
                person raising the Proposal Template.
              </Label>
              <PeoplePicker
                context={this.props.context}
                titleText="Trading Book/P&L Owner"
                personSelectionLimit={3}
                showtooltip={true}
                // isRequired={true}
                disabled={false}
                // selectedItems={this._getPeoplePickerItems}
                showHiddenInUI={false}
                ensureUser={true}
                principalTypes={[PrincipalType.User]}
                resolveDelay={1000}
              />
            </Stack>
            <Stack {...columnProps}>
              <DatePicker
                label="Target Launch Date:"
                isRequired
                // value={this.state.proposalObject.TargetCompletionDate}
              />
              <PeoplePicker
                context={this.props.context}
                titleText="Sponsor"
                personSelectionLimit={3}
                showtooltip={true}
                // isRequired={true}
                disabled={false}
                // selectedItems={this._getPeoplePickerItems}
                showHiddenInUI={false}
                ensureUser={true}
                principalTypes={[PrincipalType.User]}
                // resolveDelay={1000}
              />
              <Label className={styles.inputDesc}>
                The Sponsor generally is from the Business and must be Managing
                Director level (or a Desk Head in the case of Absa Capital).
              </Label>
              <PeoplePicker
                context={this.props.context}
                titleText="Workstream Coordinator"
                personSelectionLimit={3}
                showtooltip={true}
                // isRequired={true}
                disabled={false}
                // selectedItems={this._getPeoplePickerItems}
                showHiddenInUI={false}
                ensureUser={true}
                principalTypes={[PrincipalType.User]}
                // resolveDelay={1000}
              />
            </Stack>
          </Stack>
          <HeaderInfo
            title="Product Description"
            description="This section captures the description of NAPA. It is to be concise in order for reviewers, regardless of their expertise, to understand the NAPA. More detail can be added when the full application is submitted. Please do not embed any documents in this section."
          />
          <Stack horizontal tokens={stackTokens} styles={stackStyles}>
            <Stack tokens={stackTokens} {...columnProps}>
              <Dropdown
                label="Region:"
                multiSelect
                options={proposalRegions}
                selectedKeys={this.state.proposalObject.Region}
              />
            </Stack>
            <Stack {...columnProps}>
              <Dropdown
                label="Country:"
                options={this.state.shortCountries}
                selectedKey={this.state.proposalObject.Country0}
                defaultSelectedKey={this.state.proposalObject.Country0}
              />
            </Stack>
          </Stack>
          <Stack horizontal tokens={stackTokens} styles={stackStyles}>
            <Stack {...columnProps}>
              <Dropdown
                label="Company:"
                onChange={() => {
                  this._loadFilteredDropdown(
                    "ddlProductArea",
                    "Product_x0020_Area"
                  );
                }}
                options={this.state.companies}
                id="ddlCompany"
                defaultSelectedKey="0"
                // selectedKey={this.state.proposalObject.Company}
              />
              <Dropdown
                label="Business Area:"
                options={this.state.businessAreas}
                onChange={() => {
                  this._loadFilteredDropdown("ddlSubProducts", "Product");
                }}
                id="ddlBusinessArea"
                defaultSelectedKey="0"
                // selectedKey={this.state.proposalObject.BusinessArea}
              />
              {/*  */}
            </Stack>
            <Stack {...columnProps}>
              <Dropdown
                label="Product Area:"
                options={this.state.productAreas}
                onChange={() => {
                  this._loadFilteredDropdown("ddlBusinessArea", "Business");
                }}
                id="ddlProductArea"
                defaultSelectedKey="0"
                // selectedKey={this.state.proposalObject.ProductArea0}
              />
              {/* <FilteredDropdown
                label="Product Area:"
                context={this.props.context}
                listname="Products"
                field1={{
                  name: "Title",
                  value: this.state.proposalObject.ProductArea0,
                }}
              /> */}
              <Dropdown
                label="Sub Product:"
                options={this.state.subProducts}
                id="ddlSubProducts"
                // defaultSelectedKey="0"
                // selectedKey={this.state.proposalObject.SubProduct}
              />
            </Stack>
          </Stack>
          <TextField
            label="Executive Summary:"
            multiline
            rows={5}
            value={this.state.proposalObject.ExecutiveSummary}
          />
          <Stack horizontal tokens={stackTokens} styles={stackStyles}>
            <Stack {...columnProps}>
              <TextField
                label="What is new for this Proposal?"
                multiline
                rows={3}
                value={this.state.proposalObject.NewForProposal}
              />
              <TextField
                label="Link to Existing Proposal:"
                multiline
                rows={3}
                value={this.state.proposalObject.LinkToExistingProposal}
              />
            </Stack>
            <Stack {...columnProps}>
              <TextField
                label="Is there a specific transaction in the pipeline?"
                multiline
                rows={3}
                value={this.state.proposalObject.TransactionInPipeline}
              />
            </Stack>
          </Stack>
          <Stack horizontal tokens={stackTokens} styles={stackStyles}>
            <Stack {...columnProps}>
              <TextField
                label="Is the structure of the new product/transaction in any way influenced by
                          the anticipated tax treatment of any party to the transaction?"
                multiline
                rows={3}
                value={this.state.proposalObject.TaxTreatment}
              />
              <TextField
                label="Are there any Reputational and/or Conduct Risk issues which arise from entering into
                          this new product or amended product/services? Please provide a rationale for your answer"
                multiline
                rows={3}
              />
            </Stack>
            <Stack {...columnProps}>
              <TextField
                label="Does this NAPA constitute issuing a line of credit/an extension of credit of any type to the client?"
                multiline
                rows={3}
              />
              <TextField
                label="What do you consider to be the Principal Risks associated with this proposal?"
                multiline
                rows={3}
              />
            </Stack>
          </Stack>
          <HeaderInfo
            title="Business Hierarchy"
            description="Provide the following country information"
          />
          <Stack horizontal styles={stackStyles} tokens={stackTokens}>
            <Stack {...columnProps}>
              <Dropdown
                placeholder="Select options"
                label="Infrastructure Support Country:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.shortCountries}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Target Client Location:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.allCountries}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Country of Product Offering:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.allCountries}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Booking Location:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.shortCountries}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Trader Location:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.shortCountries}
                styles={dropdownStyles}
              />
            </Stack>
            <Stack {...columnProps}>
              <Dropdown
                placeholder="Select options"
                label="Sales/Coverage Team Location:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.shortCountries}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Target Client Sector:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.clientSectors}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Booking/Applicable Currencies:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.bookingCurrencies}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select option"
                label="Nature of Trade Activity:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                options={this.state.tradeActivities}
                styles={dropdownStyles}
              />
              <Dropdown
                placeholder="Select options"
                label="Booking Legal Entity:"
                // selectedKeys={selectedKeys}
                // eslint-disable-next-line react/jsx-no-bind
                // onChange={onChange}
                multiSelect
                options={this.state.legalEntities}
                styles={dropdownStyles}
              />
            </Stack>
          </Stack>
          <Separator />
          <Toggle
            label="Is this a joint venture divisions or business area?"
            // defaultChecked
            onText="Yes"
            offText="No"
            // onChange={_onChange}
            role="checkbox"
            checked={this.state.proposalObject.JointVenture}
          />
          <Separator />
          <Stack horizontal tokens={stackTokens}>
            <DefaultButton
              text="Cancel"
              onClick={this._cancelProposal}
              allowDisabledFocus
              className={styles.buttonsGroupInput}
            />
            <PrimaryButton
              text="Submit for NPS Determination"
              onClick={this._saveApplicationProposal}
              allowDisabledFocus
              className={styles.buttonsGroupInput}
            />
            <PrimaryButton
              text="Save as Draft"
              onClick={this._saveApplicationProposal}
              allowDisabledFocus
              className={styles.buttonsGroupInput}
            />
          </Stack>
        </Stack>
      </div>
    );
  }
}
