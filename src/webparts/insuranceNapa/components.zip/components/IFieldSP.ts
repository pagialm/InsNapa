export interface IFieldSP {
  name: string;
  value: string;
}
