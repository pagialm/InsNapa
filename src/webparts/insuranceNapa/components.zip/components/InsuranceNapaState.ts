import { IDropdownOption } from "office-ui-fabric-react";
import { IProposal } from "./IProposal";

export interface InsuranceNapaState {
  allCountries: IDropdownOption[];
  shortCountries: IDropdownOption[];
  clientSectors: IDropdownOption[];
  bookingCurrencies: IDropdownOption[];
  tradeActivities: IDropdownOption[];
  legalEntities: IDropdownOption[];
  users: [];
  companies: IDropdownOption[];
  businessAreas: IDropdownOption[];
  productAreas: IDropdownOption[];
  subProducts: IDropdownOption[];
  proposalObject: IProposal;
}
